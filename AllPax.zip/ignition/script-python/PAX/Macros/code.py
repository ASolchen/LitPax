def NavToFaceplate(perspective, button, event, path, tag):
	full_tag = path+tag
	HMI_Type = system.tag.readBlocking([full_tag+"/HMI_Type"])[0].value
	HMI_Lib = system.tag.readBlocking([full_tag+"/HMI_Lib"])[0].value
	
	title = tag #system.tag.readBlocking([full_tag+"/Cfg_Tag"])[0].value +" - " + 
	try:
		desc = system.tag.readBlocking([full_tag+"/Cfg_Desc"])[0].value
		title = title + " - "+desc
	except Exception:
		pass
	#Quick Faceplate TODO once quick faceplat is finished: 
	#Visible -> ("#122" = "2") or (("#122" = "1") and (not CurrentUserHasCode( {Security\ShowFaceplate} )))
	quick = False # for now
	popup_path = "PAX/RA-BAS/("+HMI_Lib+") "+HMI_Type+"-Faceplate"#e.g. PAX/RA-BAS/(RA-BAS) P_AIn-Faceplate
	if quick:
		popup_path = "PAX/RA-BAS/("+HMI_Lib+") "+HMI_Type+"-Quick"#e.g. PAX/RA-BAS/(RA-BAS) P_AIn-Faceplate
	idx = popup_path+tag #unique id for popup
	left = event.pageX
	top = event.pageY
	
	
	#if not button.view.params.x==None:
	#	left = button.view.params.x
	#if not button.view.params.y==None:
	#	top = button.view.params.y
	system.tag.writeBlocking(["[default]ScriptTest"], tag)
	perspective.openPopup(idx, popup_path,
	title=title,
	params={"Path":path,"Tag":tag},
	position={'left':left,'top':top})


def slowBlink():
	return True & system.date.getSecond(system.date.now())%2